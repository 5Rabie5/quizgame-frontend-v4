import { Component } from '@angular/core';

@Component({
  selector: 'app-game-room',
  standalone: true,
  templateUrl: './game-room.component.html',
  styleUrls: ['./game-room.component.scss']
})
export class GameRoomComponent {}

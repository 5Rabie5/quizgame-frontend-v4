import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'create',
    loadComponent: () =>
      import('./pages/create-game/create-game.component').then(
        (m) => m.CreateGameComponent
      ),
  },
  {
    path: 'admin',
    loadComponent: () =>
      import('./pages/admin-dashboard/admin-dashboard.component').then(
        (m) => m.AdminDashboardComponent
      ),
  },
  {
    path: 'join',
    loadComponent: () =>
      import('./pages/join/join.component').then(
        (m) => m.JoinComponent
      ),
  },
  {
    path: 'lobby',
    loadComponent: () =>
      import('./pages/lobby/lobby.component').then(
        (m) => m.LobbyComponent
      ),
  },
  {
    path: 'result',
    loadComponent: () =>
      import('./pages/result/result.component').then(
        (m) => m.ResultComponent
      ),
  },
  {
    path: 'game-room',
    loadComponent: () =>
      import('./pages/game-room/game-room.component').then(
        (m) => m.GameRoomComponent
      ),
  },
  {
    path: 'home',
    loadComponent: () =>
      import('./pages/home/home.component').then(
        (m) => m.HomeComponent
      ),
  },
  {
    path: '**',
    loadComponent: () =>
      import('./pages/not-found/not-found.component').then(
        (m) => m.NotFoundComponent
      ),
  },
];
